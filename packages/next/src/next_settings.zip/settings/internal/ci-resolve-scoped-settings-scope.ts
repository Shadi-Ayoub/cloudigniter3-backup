import type {
  CiScopedSettingsScope,
  CiSettingsDefinition,
} from "@cloudigniter/core";

/**
 * Resolve the persisted scope for a settings domain.
 *
 * Route-level settings may exist in the domain model, but they are not
 * directly persisted through the store contract.
 */
export function ciResolveScopedSettingsScope(
  definition: CiSettingsDefinition,
  settingsId: string,
): CiScopedSettingsScope {
  if (definition.scope === "route") {
    throw new Error(
      `Settings domain "${settingsId}" uses scope "route", which is not directly persisted by the Settings service store contract.`,
    );
  }

  return definition.scope;
}
