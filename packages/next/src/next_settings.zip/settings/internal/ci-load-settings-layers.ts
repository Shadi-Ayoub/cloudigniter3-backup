import type {
  CiCreateSettingsServiceInput,
  CiSettingsRecord,
  CiScopedSettingsScope,
  CiSettingsStoreGetInput,
} from "@cloudigniter/core";

export type CiLoadedSettingsLayers = {
  system?: CiSettingsRecord | null;
  global?: CiSettingsRecord | null;
  tenant?: CiSettingsRecord | null;
  user?: CiSettingsRecord | null;
};

/**
 * Load all applicable persisted layers for a settings domain.
 *
 * Merge order is handled elsewhere. This helper is only responsible for
 * retrieving candidate layers.
 */
export async function ciLoadSettingsLayers(input: {
  store: CiCreateSettingsServiceInput["store"];
  settingsId: string;
  scope: CiScopedSettingsScope;
  tenantId?: string;
  userId?: string;
}): Promise<CiLoadedSettingsLayers> {
  const layers: CiLoadedSettingsLayers = {};

  const base: Omit<
    CiSettingsStoreGetInput,
    "targetTenantScope" | "tenantId" | "userId"
  > = {
    settingsId: input.settingsId,
    scope: input.scope,
  };

  layers.system = await input.store.get({
    ...base,
    targetTenantScope: "system",
  });

  layers.global = await input.store.get({
    ...base,
    targetTenantScope: "global",
  });

  if (input.tenantId) {
    layers.tenant = await input.store.get({
      ...base,
      targetTenantScope: "tenant",
      tenantId: input.tenantId,
    });
  }

  if (input.userId) {
    layers.user = await input.store.get({
      ...base,
      targetTenantScope: input.tenantId ? "tenant" : "system",
      tenantId: input.tenantId,
      userId: input.userId,
    });
  }

  return layers;
}
