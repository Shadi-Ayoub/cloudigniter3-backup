import type {
  CiSettingsDefinition,
  CiSettingsRegistry,
} from "@cloudigniter/core";

/**
 * Resolve a required settings definition from the registry.
 */
export function ciGetRequiredSettingsDefinition(
  registry: CiSettingsRegistry,
  settingsId: string,
): CiSettingsDefinition {
  const definition = registry[settingsId];

  if (!definition) {
    throw new Error(
      `Settings definition not found for settingsId "${settingsId}".`,
    );
  }

  return definition;
}
