import type { CiSettings } from "@cloudigniter/core";

export function ciCloneSettingsValue<T>(value: T): T {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) {
    return value.map((item) => ciCloneSettingsValue(item)) as T;
  }

  if (typeof value === "object") {
    const output: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      output[key] = ciCloneSettingsValue(nestedValue);
    }

    return output as T;
  }

  return value;
}

export function ciCloneSettingsRecordValue(value: CiSettings): CiSettings {
  const output: CiSettings = {};

  for (const [key, nestedValue] of Object.entries(value)) {
    output[key] = ciCloneSettingsValue(nestedValue);
  }

  return output;
}

export function ciCloneSettingsDefaults(
  value: CiSettings | undefined,
): CiSettings {
  if (!value) return {};

  return ciCloneSettingsRecordValue(value);
}
