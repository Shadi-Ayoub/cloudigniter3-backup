import type {
  CiCanOverrideSettingsValue,
  CiSettings,
  CiSettingsLayerName,
  CiSettingsValue,
} from "@cloudigniter/core";

type CiMergeWithControlInput = {
  settingsId: string;
  base: CiSettings;
  incoming?: CiSettings | null;
  fromLayer: CiSettingsLayerName;
  toLayer: CiSettingsLayerName;
  tenantId?: string;
  userId?: string;
  canOverride?: CiCanOverrideSettingsValue;
};

export async function ciMergeSettingsWithControl(
  input: CiMergeWithControlInput,
): Promise<CiSettings> {
  const baseClone = ciDeepCloneRecord(input.base);

  if (!input.incoming) {
    return baseClone;
  }

  return ciMergeRecordsWithControl({
    settingsId: input.settingsId,
    base: baseClone,
    incoming: input.incoming,
    fromLayer: input.fromLayer,
    toLayer: input.toLayer,
    tenantId: input.tenantId,
    userId: input.userId,
    canOverride: input.canOverride,
    parentPath: "",
  });
}

async function ciMergeRecordsWithControl(input: {
  settingsId: string;
  base: CiSettings;
  incoming: CiSettings;
  fromLayer: CiSettingsLayerName;
  toLayer: CiSettingsLayerName;
  tenantId?: string;
  userId?: string;
  canOverride?: CiCanOverrideSettingsValue;
  parentPath: string;
}): Promise<CiSettings> {
  const result = ciDeepCloneRecord(input.base);

  for (const [key, incomingValue] of Object.entries(input.incoming)) {
    const path = input.parentPath ? `${input.parentPath}.${key}` : key;
    const currentValue = result[key];

    const bothObjects =
      ciIsPlainObject(currentValue) && ciIsPlainObject(incomingValue);

    if (bothObjects) {
      result[key] = await ciMergeRecordsWithControl({
        ...input,
        base: currentValue as CiSettings,
        incoming: incomingValue as CiSettings,
        parentPath: path,
      });
      continue;
    }

    if (incomingValue === undefined) {
      continue;
    }

    const allowed = input.canOverride
      ? await input.canOverride({
          settingsId: input.settingsId,
          path,
          fromLayer: input.fromLayer,
          toLayer: input.toLayer,
          tenantId: input.tenantId,
          userId: input.userId,
          currentValue: currentValue as CiSettingsValue | undefined,
          nextValue: incomingValue,
        })
      : true;

    if (currentValue === undefined || allowed) {
      result[key] = ciDeepCloneValue(incomingValue);
    }
  }

  return result;
}

function ciIsPlainObject(value: unknown): value is CiSettings {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function ciDeepCloneRecord(value: CiSettings): CiSettings {
  const output: CiSettings = {};

  for (const [key, nestedValue] of Object.entries(value)) {
    output[key] = ciDeepCloneValue(nestedValue);
  }

  return output;
}

function ciDeepCloneValue<T>(value: T): T {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) {
    return value.map((item) => ciDeepCloneValue(item)) as T;
  }

  if (typeof value === "object") {
    const output: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      output[key] = ciDeepCloneValue(nestedValue);
    }

    return output as T;
  }

  return value;
}
