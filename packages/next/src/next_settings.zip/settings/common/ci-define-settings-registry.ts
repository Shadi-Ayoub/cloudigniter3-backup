import type {
  CiDefineSettingsRegistryInput,
  CiSettings,
  CiSettingsDefinition,
  CiSettingsRegistry,
} from "@cloudigniter/core";

/**
 * Define and normalize the Settings Registry.
 */
export function ciDefineSettingsRegistry(
  input: CiDefineSettingsRegistryInput,
): CiSettingsRegistry {
  const registry: CiSettingsRegistry = {};

  for (const [settingsId, definition] of Object.entries(input)) {
    if (!definition) continue;

    registry[settingsId] = ciCloneSettingsDefinition(definition);
  }

  return registry;
}

function ciCloneSettingsDefinition(
  definition: CiSettingsDefinition,
): CiSettingsDefinition {
  return {
    scope: definition.scope,
    defaults: definition.defaults
      ? ciDeepCloneSettings(definition.defaults)
      : undefined,
    meta: definition.meta
      ? {
          title: definition.meta.title,
          description: definition.meta.description,
          category: definition.meta.category,
          tags: definition.meta.tags ? [...definition.meta.tags] : undefined,
        }
      : undefined,
  };
}

function ciDeepCloneSettings(value: CiSettings): CiSettings {
  const output: CiSettings = {};

  for (const [key, nestedValue] of Object.entries(value)) {
    output[key] = ciDeepCloneValue(nestedValue);
  }

  return output;
}

function ciDeepCloneValue<T>(value: T): T {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) {
    return value.map((item) => ciDeepCloneValue(item)) as T;
  }

  if (typeof value === "object") {
    const output: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      output[key] = ciDeepCloneValue(nestedValue);
    }

    return output as T;
  }

  return value;
}
