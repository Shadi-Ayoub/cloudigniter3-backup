import type {
  CiSettings,
  CiSettingsPath,
  CiSettingsValue,
} from "@cloudigniter/core";
import { ciResolveSettingsPath } from "./ci-resolve-settings-path";

/**
 * Return a new settings object with a nested value written at the given path.
 *
 * Behavior:
 * - does not mutate the input object
 * - creates missing intermediate objects as needed
 * - replaces non-object intermediate values with objects when necessary
 *
 * Example:
 * - ciSetSettingsValueAtPath({}, 'branding.logo.url', '/logo.svg')
 */
export function ciSetSettingsValueAtPath(
  source: CiSettings | null | undefined,
  path: CiSettingsPath,
  value: CiSettingsValue,
): CiSettings {
  const segments = ciResolveSettingsPath(path);
  const root = ciDeepCloneRecord(source ?? {});

  if (segments.length === 0) {
    return root;
  }

  let cursor: CiSettings = root;

  for (let i = 0; i < segments.length; i += 1) {
    const segment = segments[i];

    if (segment === undefined) {
      continue;
    }

    const isLast = i === segments.length - 1;

    if (isLast) {
      cursor[segment] = ciDeepCloneValue(value);
      break;
    }

    const existingValue = cursor[segment];

    if (!ciIsPlainObject(existingValue)) {
      cursor[segment] = {};
    } else {
      cursor[segment] = ciDeepCloneRecord(existingValue);
    }

    cursor = cursor[segment] as CiSettings;
  }

  return root;
}

function ciIsPlainObject(value: unknown): value is CiSettings {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function ciDeepCloneRecord(value: CiSettings): CiSettings {
  const output: CiSettings = {};

  for (const [key, nestedValue] of Object.entries(value)) {
    output[key] = ciDeepCloneValue(nestedValue);
  }

  return output;
}

function ciDeepCloneValue<T>(value: T): T {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) {
    return value.map((item) => ciDeepCloneValue(item)) as T;
  }

  if (typeof value === "object") {
    const output: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      output[key] = ciDeepCloneValue(nestedValue);
    }

    return output as T;
  }

  return value;
}
