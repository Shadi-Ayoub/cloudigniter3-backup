import type { CiSettingsPath } from "@cloudigniter/core";

/**
 * Normalize a dot-separated settings path into safe path segments.
 *
 * Examples:
 * - "applicationName" => ["applicationName"]
 * - "branding.logo.url" => ["branding", "logo", "url"]
 * - " branding . logo . url " => ["branding", "logo", "url"]
 *
 * Invalid or empty segments are removed.
 */
export function ciResolveSettingsPath(path: CiSettingsPath): string[] {
  if (!path || typeof path !== "string") {
    return [];
  }

  return path
    .split(".")
    .map((segment) => segment.trim())
    .filter(Boolean);
}
