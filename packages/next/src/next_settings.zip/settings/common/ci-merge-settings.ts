import type { CiSettings } from "@cloudigniter/core";

/**
 * Deep-merge two settings objects.
 *
 * Merge rules:
 * - plain object + plain object => recursively merged
 * - arrays are replaced, not concatenated
 * - scalar values replace previous values
 * - `undefined` in override is ignored
 *
 * Typical use:
 * - merge registry defaults with persisted overrides
 */
export function ciMergeSettings<
  TBase extends CiSettings,
  TOverride extends CiSettings,
>(base: TBase, override?: TOverride | null): TBase & TOverride {
  const baseClone = ciDeepCloneValue(base) as CiSettings;

  if (!override) {
    return baseClone as TBase & TOverride;
  }

  return ciMergeRecords(baseClone, override as CiSettings) as TBase & TOverride;
}

function ciMergeRecords(base: CiSettings, override: CiSettings): CiSettings {
  const result: CiSettings = { ...base };

  for (const [key, overrideValue] of Object.entries(override)) {
    if (overrideValue === undefined) {
      continue;
    }

    const currentValue = result[key];

    if (ciIsPlainObject(currentValue) && ciIsPlainObject(overrideValue)) {
      result[key] = ciMergeRecords(
        ciDeepCloneValue(currentValue) as CiSettings,
        ciDeepCloneValue(overrideValue) as CiSettings,
      );
      continue;
    }

    result[key] = ciDeepCloneValue(overrideValue);
  }

  return result;
}

function ciIsPlainObject(value: unknown): value is CiSettings {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function ciDeepCloneValue<T>(value: T): T {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) {
    return value.map((item) => ciDeepCloneValue(item)) as T;
  }

  if (typeof value === "object") {
    const output: Record<string, unknown> = {};

    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      output[key] = ciDeepCloneValue(nestedValue);
    }

    return output as T;
  }

  return value;
}
