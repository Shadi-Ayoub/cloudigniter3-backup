import type {
  CiSettings,
  CiSettingsPath,
  CiSettingsValue,
} from "@cloudigniter/core";
import { ciResolveSettingsPath } from "./ci-resolve-settings-path";

/**
 * Read a nested settings value using a dot-separated path.
 *
 * Examples:
 * - ciGetSettingsValueAtPath(settings, 'branding.logo.url')
 * - ciGetSettingsValueAtPath(settings, 'applicationName')
 *
 * Returns:
 * - the resolved value when found
 * - `undefined` when the path cannot be resolved
 */
export function ciGetSettingsValueAtPath<TValue = CiSettingsValue>(
  source: CiSettings | null | undefined,
  path: CiSettingsPath,
): TValue | undefined {
  if (!source) return undefined;

  const segments = ciResolveSettingsPath(path);

  if (segments.length === 0) {
    return undefined;
  }

  let current: unknown = source;

  for (const segment of segments) {
    if (!ciIsIndexableObject(current)) {
      return undefined;
    }

    current = current[segment];
  }

  return current as TValue | undefined;
}

function ciIsIndexableObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
