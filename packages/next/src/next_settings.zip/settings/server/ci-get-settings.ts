import type {
  CiGetSettingsInput,
  CiGetSettingsResult,
  CiSettingsService,
} from "@cloudigniter/core";

/**
 * Convenience helper for reading resolved settings through a service instance.
 *
 * This keeps handler/service-call sites concise while preserving the main
 * service contract as the canonical execution path.
 */
export async function ciGetSettings(
  service: CiSettingsService,
  input: CiGetSettingsInput,
): Promise<CiGetSettingsResult> {
  return service.get(input);
}
