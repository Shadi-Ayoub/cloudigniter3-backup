import type {
  CiDeleteSettingsInput,
  CiDeleteSettingsResult,
  CiSettingsService,
} from "@cloudigniter/core";

/**
 * Convenience helper for deleting persisted settings overrides
 * through a service instance.
 */
export async function ciDeleteSettings(
  service: CiSettingsService,
  input: CiDeleteSettingsInput,
): Promise<CiDeleteSettingsResult> {
  return service.delete(input);
}
