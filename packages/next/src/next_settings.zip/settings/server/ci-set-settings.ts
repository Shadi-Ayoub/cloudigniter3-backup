import type {
  CiSetSettingsInput,
  CiSetSettingsResult,
  CiSettingsService,
} from "@cloudigniter/core";

/**
 * Convenience helper for writing settings through a service instance.
 */
export async function ciSetSettings(
  service: CiSettingsService,
  input: CiSetSettingsInput,
): Promise<CiSetSettingsResult> {
  return service.set(input);
}
