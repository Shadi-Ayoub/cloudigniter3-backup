import type {
  CiInitializeSettingsIfMissingResult,
  CiSettingsService,
  CiSetSettingsInput,
} from "@cloudigniter/core";
import type {
  CiSettings,
  CiScopedSettingsScope,
  CiTenantScope,
} from "@cloudigniter/core";

type CiInitializeSettingsIfMissingInput = {
  service: CiSettingsService;
  settingsId: string;
  scope: CiScopedSettingsScope;
  value: CiSettings;
  tenantId?: string;
  userId?: string;
  targetTenantScope?: CiTenantScope;
};

/**
 * Initialize a persisted settings record only if the targeted record
 * does not already exist.
 *
 * Important:
 * - this checks for the exact targeted persisted layer/record
 * - it does NOT rely on the final merged value
 * - therefore it correctly distinguishes "record exists" from
 *   "value was inherited from fallback layers"
 */
export async function ciInitializeSettingsIfMissing(
  input: CiInitializeSettingsIfMissingInput,
): Promise<CiInitializeSettingsIfMissingResult> {
  const existing = await input.service.get({
    settingsId: input.settingsId,
    tenantId: input.tenantId,
    userId: input.userId,
  });

  const alreadyExists = ciHasMatchingPersistedLayer({
    settingsId: input.settingsId,
    scope: input.scope,
    tenantId: input.tenantId,
    userId: input.userId,
    targetTenantScope: input.targetTenantScope,
    getResult: existing,
  });

  if (alreadyExists) {
    return {
      ok: true,
      initialized: false,
      settingsId: input.settingsId,
      scope: input.scope,
      tenantId: input.tenantId,
      userId: input.userId,
    };
  }

  await input.service.set({
    settingsId: input.settingsId,
    scope: input.scope,
    tenantId: input.tenantId,
    userId: input.userId,
    targetTenantScope: input.targetTenantScope,
    value: input.value,
  });

  return {
    ok: true,
    initialized: true,
    settingsId: input.settingsId,
    scope: input.scope,
    tenantId: input.tenantId,
    userId: input.userId,
  };
}

function ciHasMatchingPersistedLayer(input: {
  settingsId: string;
  scope: CiScopedSettingsScope;
  tenantId?: string;
  userId?: string;
  targetTenantScope?: CiSetSettingsInput["targetTenantScope"];
  getResult: Awaited<ReturnType<CiSettingsService["get"]>>;
}): boolean {
  const layers = input.getResult.layers;

  if (!layers) {
    return false;
  }

  if (input.scope === "user") {
    const record = layers.user;
    if (!record) return false;

    return (
      record.scope === "user" &&
      record.userId === input.userId &&
      ciMatchesTenantTarget(
        record.tenantId,
        input.targetTenantScope,
        input.tenantId,
      )
    );
  }

  if (input.targetTenantScope === "global") {
    const record = layers.global;
    if (!record) return false;

    return record.scope === input.scope;
  }

  if (input.targetTenantScope === "tenant") {
    const record = layers.tenant;
    if (!record) return false;

    return record.scope === input.scope && record.tenantId === input.tenantId;
  }

  const record = layers.system;
  if (!record) return false;

  return record.scope === input.scope;
}

function ciMatchesTenantTarget(
  recordTenantId: string | undefined,
  targetTenantScope: CiSetSettingsInput["targetTenantScope"],
  tenantId?: string,
): boolean {
  if (targetTenantScope === "tenant") {
    return recordTenantId === tenantId;
  }

  if (targetTenantScope === "system") {
    return recordTenantId === undefined;
  }

  if (targetTenantScope === "global") {
    return recordTenantId === undefined;
  }

  if (tenantId) {
    return recordTenantId === tenantId;
  }

  return recordTenantId === undefined;
}

// function ciResolveRequiredScopedScope(scope: CiSetSettingsInput['scope']): CiScopedSettingsScope {
//   if (!scope) {
//     throw new Error('scope is required for initialization.');
//   }

//   return scope;
// }
