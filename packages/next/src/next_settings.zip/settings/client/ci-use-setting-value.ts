import { useMemo } from "react";
import {
  ciGetSettingsValueAtPath,
  type CiSettings,
  type CiUseSettingValueOptions,
  type CiUseSettingValueResult,
} from "@cloudigniter/core";
import { useCiSettings } from "./ci-use-settings";

/**
 * Read one nested value from resolved settings.
 *
 * @param options - Hook options.
 * @returns Hook state for the selected nested value.
 */
export function useCiSettingValue<TValue = unknown>(
  options: CiUseSettingValueOptions<TValue>,
): CiUseSettingValueResult<TValue> {
  const { settingsId, path, fallbackValue, enabled } = options;

  const settings = useCiSettings<CiSettings>({
    settingsId,
    enabled,
  });

  return useMemo(
    () => ({
      data: settings.data
        ? ((ciGetSettingsValueAtPath(settings.data, path) ?? fallbackValue) as
            | TValue
            | undefined)
        : fallbackValue,
      isLoading: settings.isLoading,
      error: settings.error,
      refresh: settings.refresh,
    }),
    [
      fallbackValue,
      path,
      settings.data,
      settings.isLoading,
      settings.error,
      settings.refresh,
    ],
  );
}
