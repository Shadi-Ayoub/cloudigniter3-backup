import { useMemo, useState } from "react";
import type {
  CiSettings,
  CiUseSettingsOptions,
  CiUseSettingsResult,
} from "@cloudigniter/core";

/**
 * Minimal client hook for resolved settings consumption.
 *
 * This reference implementation is intentionally light. In a real application,
 * wire this hook to your server endpoint or data-fetching layer.
 *
 * @param options - Hook options.
 * @returns Hook state.
 */
export function useCiSettings<TSettings extends CiSettings = CiSettings>(
  options: CiUseSettingsOptions<TSettings> = {},
): CiUseSettingsResult<TSettings> {
  const { fallbackValue } = options;

  const [data] = useState<TSettings | undefined>(fallbackValue);
  const [error] = useState<string | undefined>();

  return useMemo(
    () => ({
      data,
      isLoading: false,
      error,
      refresh: async () => {},
    }),
    [data, error],
  );
}
