import { CiSettingsFormSection } from "./CiSettingsFormSection";
import { CiSmartFormField } from "@/ui";

export const CiEmailSettingsSection = () => {
  return (
    <CiSettingsFormSection title="Security Settings">
      <CiSmartFormField
        type="input"
        name="email.emailSender"
        label="Sender Email"
        iconType="warning"
      />
    </CiSettingsFormSection>
  );
};
